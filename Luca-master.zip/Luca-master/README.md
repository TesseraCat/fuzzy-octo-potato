# Luca
Luca is the best bot you'll need for managing and informing members of the server
